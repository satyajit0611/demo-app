import React from 'react';

import { Outlet, Link } from "react-router-dom";
function Home() {
  return (
    <div className="App">
        home
        
      <Link to="/">App</Link>
    </div>
  );
}

export default Home;
