import React from 'react';

function Default(children:Element) {
  return (
    <div className="App">
        Hello World
    </div>
  );
}

export default Default;
